# Part III: SubAgent Layer — Composable Pipelines + 13 SubAgents

## 3.1 BaseSubAgent Class

```python
class BaseSubAgent(ABC):
    """
    SubAgents compose multiple workers into directed pipelines.
    Each SubAgent is a mini-DAG: Plan → Execute → Fuse.

    PIPELINE PATTERN:
        step 1 → step 2a ─┐
                  step 2b ─┤ → step 3 (fuse) → result
                  step 2c ─┘

    KEY PROPERTIES:
        - SubAgents don't call other SubAgents (no nesting)
        - SubAgents can call Workers and infrastructure Agents
        - Results are Pydantic models (type-safe)
        - Cost aggregated from all worker calls
        - Circuit breakers on every worker call (v10)
    """

    name: str
    pipeline_steps: list[str]      # Ordered step names
    parallel_steps: set[str] = set()  # Steps that can run in parallel

    @abstractmethod
    async def run(self, input_data: dict) -> dict:
        """Execute the pipeline and return aggregated result."""
        pass

    async def run_parallel(self, steps: list[callable], inputs: list[dict]) -> list[dict]:
        """Run multiple worker calls in parallel."""
        return await asyncio.gather(*[step(inp) for step, inp in zip(steps, inputs)])
```

---

## 3.2 Complete SubAgent Inventory (13 SubAgents)

### RAG Pipeline SubAgents (5)

#### RAGPipelineSubAgent — Master RAG Orchestrator
```
PIPELINE: Plan → Retrieve(×N parallel) → Rerank → ContextBuild → BriefSynth

    Step 1: ReasonPlanSubAgent
        Input:  user query
        Output: 3-5 sub-questions + retrieval strategy
        Worker: ReasonPlanWorker (Tier-3)

    Step 2: RetrieveSubAgent (× N parallel)
        Input:  sub-questions from Step 1
        Output: N result sets from ChromaDB
        Worker: RAGWorker (Tier-0) per sub-question

    Step 3: RerankSubAgent
        Input:  N result sets
        Output: top-K ranked documents (cross-encoder)
        Worker: EmbedWorker (Tier-0)

    Step 4: ContextBuildSubAgent
        Input:  top-K documents
        Output: structured context window (≤4K tokens)
        Worker: ContextBuildWorker (Tier-0)

    Step 5: BriefSynthSubAgent (MoA)
        Input:  structured context
        Output: intelligence brief
        Workers: 3× BriefWorker (Tier-3) + 1 aggregation
```

#### BriefSynthSubAgent — Mixture of Agents
```python
class BriefSynthSubAgent(BaseSubAgent):
    """
    3-proposer + 1-aggregator Mixture-of-Agents pattern.

    PROPOSERS (parallel): 3× BriefWorker with different prompts
    AGGREGATOR: Select best + combine insights

    v10 FIX: MoAFallbackSubAgent handles aggregator failure
        Level 0: GPT-OSS:20b full MoA aggregation (primary)
        Level 1: Groq llama-3.3-70b aggregation (cloud fallback)
        Level 2: Scoring-based selection (highest confidence)
        Level 3: Return all 3 to admin for manual pick

    INVARIANT: All 3 proposals saved to SQLite BEFORE aggregation.
    """
    name = "BriefSynthSubAgent"
    pipeline_steps = ["propose_×3", "aggregate"]
    parallel_steps = {"propose_×3"}
```

### Quality Assurance SubAgents (3)

#### SourceFeedbackSubAgent
```python
class SourceFeedbackSubAgent(BaseSubAgent):
    """
    Adjusts source credibility scores based on FactCheck results.

    v10 FIX: Escalating penalties (not flat -0.05)
        1st quarantine: -0.05
        2nd (within 30d): -0.10
        3rd (within 30d): -0.20
        4th: PERMANENT FLAG → admin override required

    v10 FIX: Source clustering
        If source permanently flagged → SourceClusterSubAgent
        checks for related sources (IP/domain/author/style).
        Penalty applies to entire cluster.
    """
    name = "SourceFeedbackSubAgent"
```

#### SemanticDriftMonitor
```
SCHEDULE: Weekly
CHECK: Compare embedding distribution of last week vs baseline
METHOD: KL divergence on document embeddings per source
ALERT: If KL > 0.30 on any source → flag for review
```

#### HallucinationCheckSubAgent
```
PIPELINE: 7-step FactCheck (from FactCheckAgent)
    1. Claim extraction (ClaimWorker)
    2. Evidence retrieval (RAGWorker)
    3. Evidence scoring (VerifierWorker)
    4. Cross-reference check (3 sources minimum)
    5. Confidence calibration
    6. Hallucination floor check (≥ 0.70)
    7. Quarantine decision
```

### v10 New SubAgents (5)

#### SummarizationVerifierSubAgent
```python
class SummarizationVerifierSubAgent(BaseSubAgent):
    """
    Catches semantic distortion in marketing summaries/tweets.
    FIXES: v9 GAP 2

    CHECKS:
        1. Extract numerical values from source data
        2. Extract directional language from summary
        3. Verify direction matches data trend
        4. Verify magnitude band matches score:
            0.0-0.30 = "minimal/negligible"
            0.30-0.50 = "low/modest"
            0.50-0.70 = "moderate/notable"
            0.70-0.85 = "high/significant"
            0.85-1.00 = "critical/severe"
        5. If summary uses HIGHER band language than data → REJECT
    """
    name = "SummarizationVerifierSubAgent"
```

#### SourceClusterSubAgent
```python
class SourceClusterSubAgent(BaseSubAgent):
    """
    Detects coordinated source networks. FIXES: v9 GAP 3

    CLUSTERING DIMENSIONS:
        - IP address range
        - Domain/subdomain
        - Author/byline
        - Writing style (embedding cosine > 0.90)
    If source A is flagged → penalty applies to entire cluster.
    """
    name = "SourceClusterSubAgent"
```

#### OverridePatternSubAgent
```python
class OverridePatternSubAgent(BaseSubAgent):
    """
    Detects admin override abuse patterns. FIXES: v9 GAP 6

    PATTERNS:
        - Volume: >5 overrides/week → ALERT
        - Source favouritism: same source approved >3 times → ALERT
        - Time clustering: >3 overrides in 1 hour → ALERT
        - FactCheck bypass rate: >20% quarantined briefs approved → ALERT
    """
    name = "OverridePatternSubAgent"
```

#### MoAFallbackSubAgent
```python
class MoAFallbackSubAgent(BaseSubAgent):
    """
    4-level fallback for MoA aggregation failure. FIXES: v9 GAP 5

    CHAIN:
        Level 0: GPT-OSS:20b (primary)
        Level 1: Groq llama-3.3-70b (cloud)
        Level 2: Scoring (pick highest confidence)
        Level 3: Manual (queue for admin)

    INVARIANT: Proposals ALWAYS saved before aggregation.
    """
    name = "MoAFallbackSubAgent"
```

#### PenetrationTestSubAgent
```python
class PenetrationTestSubAgent(BaseSubAgent):
    """
    Runs 8 automated penetration tests. Schedule: weekly (Sunday).

    TESTS:
        1. Prompt injection via crafted articles
        2. Schema bypass (>2048 token input to Tier-1)
        3. Source credibility gaming (4 quarantines)
        4. API key leakage (grep logs for key patterns)
        5. Admin CLI brute force (6 wrong passwords)
        6. Message contract violation (malformed AgentMessage)
        7. ChromaDB direct write (bypass single-writer)
        8. Rate limit verification (flood ingestion endpoint)
    """
    name = "PenetrationTestSubAgent"
```

## CROSS-CHECK ✅
```
✓ 13 subagents listed (8 v9 + 5 v10)
✓ RAG pipeline fully documented (5-step)
✓ MoA pattern with v10 fallback chain
✓ All v10 subagents map to specific gap fixes
✓ SourceFeedback has escalating penalties (v10 fix)
✓ HallucinationCheck enforces 0.70 floor
✓ No SubAgent nesting (SubAgents don't call SubAgents)
```
